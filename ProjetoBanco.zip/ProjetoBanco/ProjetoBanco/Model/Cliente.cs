﻿using NUnit.Framework;
using ProjetoBanco.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoBanco.Model
{
    public  class Cliente
    {
        public int ID { get; set; }
        public string Nome { get; set; }

    }
}
