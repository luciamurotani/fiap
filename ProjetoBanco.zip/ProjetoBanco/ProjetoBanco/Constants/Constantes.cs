﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoBanco.Constants
{
    public static class Constantes
    {
        public static readonly string SIGLA_RESTRICAO = "SIGLA_RESTRICAO";
    }
}
