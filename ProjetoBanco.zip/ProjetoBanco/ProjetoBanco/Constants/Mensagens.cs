﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoBanco.Constants
{
    public static class Mensagem
    {
        public static readonly string MS_001 = "Empréstimo realizado com sucesso!";
        public static readonly string MS_002 = "Digite um número válido";
    }
}
