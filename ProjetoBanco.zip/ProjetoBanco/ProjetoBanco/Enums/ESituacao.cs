﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoBanco.Enums
{
    public enum ESituacao
    {
        Aberta = 1,
        Fechada = 2
    }
}
