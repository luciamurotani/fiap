﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var x = Math.Pow(2, 2);
            Console.WriteLine(x);
        }
    }
}