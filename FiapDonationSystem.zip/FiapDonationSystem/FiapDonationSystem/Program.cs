﻿namespace FiapDonationSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Produto p = new Produto();
            p.nome = "sapato";
            p.descricao = "sapato rosa novo";
            p.genero = "feminino";
            p.foto = "sem foto";
            p.status = true;

            Console.WriteLine(p.exibirDados());
        }
    }
}