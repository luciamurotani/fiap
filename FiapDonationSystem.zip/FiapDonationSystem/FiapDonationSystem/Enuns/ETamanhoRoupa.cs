﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem.Enum
{
    public enum ETamanhoRoupa
    {
        P,
        M,
        G,
        GG,
        [Description("2")]
        _2,
        [Description("4")]
        _4,
        _6,
        _8,
        _10,
        _12,
        _14,
        _16


    }
}
