﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem.Enum
{
    public enum ETipoAjuste
    {
        Cadarco = 0,
        Velcro =1,
        Botao = 2,
        Cacefacil =3,
        Ziper =4
    }
}
