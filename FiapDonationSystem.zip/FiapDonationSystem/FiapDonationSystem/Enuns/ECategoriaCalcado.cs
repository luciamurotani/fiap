﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem.Enum
{
    public enum ECategoriaCalcado
    {
        Sandalias,
        Sapatilhas,
        Tenis,
        Botas
    }
}
