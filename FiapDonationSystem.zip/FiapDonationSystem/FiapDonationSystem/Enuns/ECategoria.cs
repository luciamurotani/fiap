﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem
{
    public enum ECategoria
    {
        Vestido =1,
        Jeans,
        Camisetas,
        Blusas,
        Calcas,
        Saias,
        Shorts,
        Pijamas
    }
}
