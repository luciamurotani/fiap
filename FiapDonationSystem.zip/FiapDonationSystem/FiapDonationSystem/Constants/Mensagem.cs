﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem.Constants
{
    public static class Mensagem
    {
        public static readonly string MS_001 = "Cadastro realizado com sucesso!";
        public static readonly string MS_002 = "Digite um número válido";
    }
}
