﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiapDonationSystem
{
    internal class Produto
    {
        public String nome;
        public String descricao;
        public String genero;
        public String foto;
        public Boolean status;

        public String exibirDados()
        {
            String valorRetorno;
            valorRetorno = "Nome: " + nome + "\nDescrição: " + descricao + "\nGênero: " + genero + "\nFoto: " + foto + "\nStatus: " + status;
            return valorRetorno;

        }

    }
}
