﻿namespace ProjetoLivraria
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Agora é uma classe abstrata, não pode ser instânciada
            // Livro livro = new Livro(); 

            Editora editora = new Editora();
            editora.Nome = "HarperrCollins";

            LivroFisico livroFisico = new LivroFisico("As Crônicas de Nárnia - Coleção de Luxo", "Viagen ao fim do mundo, criaturas fantásticas e " +
               "batalhas épicas entre o bem e o mal - o que mais um leitor poderia querer de um livro?", "C. S. Lewis", 100, 752, editora, "capa");

            livroFisico.exibirDados();


            ////Instanciando um objeto do tipo Livro utilizando o contrutor sem parâmetros, cria os objetos em memória com valores default
            //Console.WriteLine("Livro com construtor sem parâmetros: ");
            //Livro livro1 = new Livro();
            //livro1.Nome = ("As Crônicas de Nárnia - Coleção de Luxo");
            //livro1.Valor = (100);
            //livro1.Resumo = ("Viagen ao fim do mundo, criaturas fantásticas e " +
            //    "batalhas épicas entre o bem e o mal -" +
            //    "o que mais um leitor poderia querer de um livro?");
            //livro1.Paginas = (752);
            //livro1.Autor = ("C. S. Lewis");

            ////Instanciando um objeto do tipo Editora
            //Editora editora = new Editora();
            //editora.Nome = "xxxxx";
            //editora.Telefone = "19 88888-88888";

            //Editora editora1 = new Editora();
            //editora1.Nome = "HarperrCollins";
            //editora1.Telefone = "19 88888-88888";
            //livro1.Editora = editora1;
            //livro1.exibirDados();

            //Console.WriteLine("---------------------------------------------------------");


            //Livro livro2 = new Livro("As Crônicas de Nárnia - Coleção de Luxo");
            //Console.Write("Livro com construtor de 1 parâmetro: \n");
            //livro2.exibirDados();
            //Console.WriteLine("---------------------------------------------------------");

            //Livro livro3 = new Livro("As Crônicas de Nárnia - Coleção de Luxo",
            //    "Viagen ao fim do mundo, criaturas fantásticas e " +
            //   "batalhas épicas entre o bem e o mal -" +
            //  "o que mais um leitor poderia querer de um livro?", "C.S.Lewis", 100, 752);
            //Console.Write("\nLivro com construtor com todos parâmetros: \n");
            //livro3.exibirDados();
            //Console.WriteLine("---------------------------------------------------------");
        }
    }
}